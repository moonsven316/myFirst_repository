@extends("layouts.mypage")

@php
	$user = Auth::user();
@endphp

@section('content')
<section class="content">
	<div class="block-header">
		<div class="row">
			<div class="col-lg-7 col-md-6 col-sm-12">
				<h2>商品一覧</h2>
				<ul class="breadcrumb">
					<li class="breadcrumb-item"><a href="/"><i class="zmdi zmdi-home"></i> Amazon</a></li>
					<li class="breadcrumb-item active">商品一覧</li>
				</ul>
				<button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
			</div>
			<div class="col-lg-5 col-md-6 col-sm-12">
				<a style="color: white;" href="{{ route('csv_down') }}" class="btn btn-primary btn-icon float-right"><i class="zmdi zmdi-download"></i></a>
				<button class="btn btn-primary btn-icon float-right" type="button" onclick="deleteProduct('{{$user->id}}')"><i class="zmdi zmdi-delete"></i></button>
				<button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>
			</div>
		</div>
	</div>

	<div class="container-fluid">
		<div class="row clearfix">
			<div class="col-12">
				<div class="card widget_2 big_icon">
					<div class="body">
						<div class="table-responsive">
							<table class="table table-hover table-striped product_item_list c_table theme-color mb-0">
								<thead>
									<tr>
										<th colspan="1" rowspan="1">No</th>
										<th colspan="1" rowspan="1">ASIN</th>
										<th colspan="1" rowspan="1">画像</th>
										<th colspan="1" rowspan="1">目標価格</th>
										<th colspan="1" rowspan="1">現在価格</th>
										<th colspan="1" rowspan="1">下落％</th>
										<!-- <th colspan="1" rowspan="1" data-breakpoints="md sm xs">Keepa URL</th> -->
										<th colspan="1" rowspan="1" data-breakpoints="md sm xs">再通知間隔</th>
									</tr>
								</thead>
								<tbody>
									@foreach ($products as $product)
										<tr data-id="{{ $product->id }}">
											<td colspan="1" rowspan="1">{{ $loop->iteration + ($products->currentPage() - 1) * 10 }}</td>
											<td colspan="1" rowspan="1">{{ $product->asin }}</td>
											<td colspan="1" rowspan="1">
												<a href="{{ 'https://keepa.com/#!product/5-' . $product->asin }}" target="_blank"><img src="{{ $product->image }}" style="width: 48px; height: 48px;" /></a>
											</td>
											<td colspan="1" rowspan="1">{{ $product->reg_price }}</td>
											<td colspan="1" rowspan="1">{{ $product->price }}</td>
											<td colspan="1" rowspan="1">{{ $product->pro }}</td>
											<!-- <td colspan="1" rowspan="1">
												<a href="{{ 'https://keepa.com/#!product/5-' . $product->asin }}" target="_blank">{{ 'https://keepa.com/#!product/5-' . $product->asin }}</a>
											</td> -->
											<td colspan="1" rowspan="1">{{ $user->interval }}</td>
										</tr>
									@endforeach
								</tbody>
							</table>
						</div>
					</div>

					@if (count($products)) {{ $products->onEachSide(1)->links('mypage.pagination') }} @endif
				</div>
			</div>
		</div>
	</div>
</section>
@endsection

@push('scripts')
	<script>
		function deleteProduct(id) {
			toastr.info('少々お待ちください。')
			$.ajax({
				url: '{{ route("delete_product") }}',
				type: 'post',
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				},
				data: {
					user_id: id
				},
				success: function () {
					toastr.success('データが正常に削除されました。');
					setTimeout(() => {
						location.href = './';
					}, 3000);
				}
			})
		}
	</script>
@endpush