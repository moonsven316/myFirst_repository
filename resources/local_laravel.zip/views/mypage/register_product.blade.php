@extends("layouts.mypage")

@php
	$user = Auth::user();
@endphp

@section('content')
<section class="content">
	<div class="block-header">
		<div class="row">
			<div class="col-lg-7 col-md-6 col-sm-12">
				<h2>商品登録</h2>
				<ul class="breadcrumb">
					<li class="breadcrumb-item"><a href="/"><i class="zmdi zmdi-home"></i> Amazon</a></li>
					<li class="breadcrumb-item active">商品登録</li>
				</ul>
				<button class="btn btn-primary btn-icon mobile_menu" type="button"><i
						class="zmdi zmdi-sort-amount-desc"></i></button>
			</div>
			<div class="col-lg-5 col-md-6 col-sm-12">
				<button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i
						class="zmdi zmdi-arrow-right"></i></button>
			</div>
		</div>
	</div>

	<div class="container-fluid">
		<div class="row clearfix">
			<div class="col-lg-3 col-md-12"></div>
			<div class="col-lg-6 col-md-12">
				<div class="card widget_2 big_icon">
					<div class="body">
						<div class="table-responsive">
							<table class="table table-hover product_item_list c_table theme-color mb-0">
								<thead>
									<tr>
										<th style="width: 30%;">【価格改定】</th>
										<th style="width: 70%;"></th>
									</tr>
								</thead>
								<tbody> 
									<tr>
										<td>秒数:</td>
										<td><input type="number" class="form-control" placeholder="1200" id="interval" name="interval" value="{{ $user->interval }}" /></td>
									</tr>
									<tr>
										<td>1-5000円(%):</td>
										<td><input type="number" class="form-control" placeholder="50" id="five" name="five" min="0" max="100" value="{{ $user->five }}" /></td>
									</tr>
									<tr>
										<td>5001-10000円(%):</td>
										<td><input type="number" class="form-control" placeholder="50" id="ten" name="ten" min="0" max="100" value="{{ $user->ten }}" /></td>
									</tr>
									<tr>
										<td>10001-20000円(%):</td>
										<td><input type="number" class="form-control" placeholder="50" id="twenty" name="twenty" min="0" max="100" value="{{ $user->twenty }}" /></td>
									</tr>
									<tr>
										<td>20001-30000円(%):</td>
										<td><input type="number" class="form-control" placeholder="50" id="thirty" name="thirty" min="0" max="100" value="{{ $user->thirty }}" /></td>
									</tr>
									<tr>
										<td>30001円以上(%):</td>
										<td><input type="number" class="form-control" placeholder="50" id="over" name="over" min="0" max="100" value="{{ $user->over }}" /></td>
									</tr>
									<tr>
										<td>CSVファイル:</td>
										<td><input type="file" class="form-control" style="cursor: pointer;" placeholder="CSVファイルを選択してください。" id="csv" name="csv" /></td>
									</tr>
								</tbody>
							</table>
						</div>
						<div class="col-lg-12 mt-4">
							<div class="row">
								<div class="col text-center">
									<span id="progress-num">0</span> 件/ <span id="total-num">0</span> 件
								</div>
								<div class="col text-center">
									<!-- <span id="round">0</span>回目 -->
								</div>
							</div>
							<div class="row mt-4">
								<div class="progress col-12" id="count">
									<div class="progress-bar progress-bar-animated bg-info progress-bar-striped" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%; height: 20px;" id="progress">
										<span id="percent-num">0%</span>
									</div>
								</div>
							</div>
						</div>
						<div class="col-12 text-center mt-4">
							<button type="button" id="register" class="btn btn-raised btn-primary waves-effect" onclick="register()">起 動</button>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-12"></div>
		</div>
	</div>
</section>
@endsection

@push('scripts')
	<script>
		$(document).ready(function () {
			scan();
			setInterval(scan, 5000);

			var user = <?php echo $user; ?>;
			if (user.is_reg == 1) {
				$('#total-num').html(user.len);
				// $('#round').html(user.round);
				$('#csv').attr('disabled', true);
				$('#register').attr('disabled', true);
			}
		});

		function scan() {
			$.ajax({
				url: "{{ route('scan') }}",
				type: "get",
				success: function(response) {
					$('#progress-num').html(response.reg_num);
					let percent = Math.floor(response.reg_num / response.len * 100);
					$('#percent-num').html(percent + '%');
					$('#progress').attr('aria-valuenow', percent);
					$('#progress').css('width', percent + '%');
					// $('#round').html(response.round);
					if (percent == 100) {
						toastr.success('正常に登録されました。');
						$('#csv').attr('disabled', false);
						$('#register').attr('disabled', false);
						
						setTimeout(function() {
							location.href = './list_product';
						}, 2000);
						
						clearInterval(scanInterval);
					}
				}
			})
		}

		const register = async () => {
			var user = <?php echo $user; ?>;
			// if (user.is_permitted == 0) {
			// 	toastr.error('管理者からの許可をお待ちください。');
			// 	return;
			// }

			if (csvFile === undefined) {
				toastr.error('CSVファイルを選択してください。');
				return;
			}

			let postData = {
				interval: $('input[name="interval"]').val(),
				five: $('input[name="five"]').val(),
				ten: $('input[name="ten"]').val(),
				twenty: $('input[name="twenty"]').val(),
				thirty: $('input[name="thirty"]').val(),
				over: $('input[name="over"]').val(),
				file_name: csvFile.name,
				len: newCsvResult.length,
			};

			// first save user exhibition setting
			await $.ajax({
				url: 'save_user_setting',
				type: 'post',
				headers: {
					"X-CSRF-TOKEN" : $('meta[name="csrf-token"]').attr("content")
				},
				data: {
					exData: JSON.stringify(postData)
				},
				success: function () {
					toastr.info('商品登録を開始します。');
					$('#csv').attr('disabled', true);
					$('#register').attr('disabled', true);
				}
			});

			// then start registering products with ASIN code
			postData = {
				user_id: '{{ Auth::user()->id }}',
				codes: newCsvResult
			};

			$.ajax({
				url: "http://localhost:32768/api/v1/amazon/getInfo",
				type: "post",
				data: {
					asin: JSON.stringify(postData)
				},
			});
		};

		var newCsvResult, csvFile;
		// select csv file and convert its content into an array of ASIN code
		$('body').on('change', '#csv', function(e) {
			csvFile = e.target.files[0];
			newCsvResult = [];

			$('#progress-num').html('0');
			$('#percent-num').html('0%');
			$('#progress').attr('aria-valuenow', 0);
			$('#progress').css('width', '0%');

			var ext = $('#csv').val().split(".").pop().toLowerCase();
			if ($.inArray(ext, ["csv"]) === -1) {
				toastr.error('CSVファイルを選択してください。');
				return false;
			}
			
			if (csvFile !== undefined) {
				reader = new FileReader();
				reader.onload = function (e) {
					$('#count').css('visibility', 'visible');
					csvResult = e.target.result.split(/\n/);

					for (const i of csvResult) {
						let code = i.split('\r');
						code = i.split('"');

						if (code.length == 1) {
							code = i.split('\r');
							if (code[0] != '') {
								newCsvResult.push(code[0]);
							}
						} else {
							newCsvResult.push(code[1]);
						}
					}
					
					if (newCsvResult[0] == 'ASIN') { newCsvResult.shift(); }

					$('#total-num').html(newCsvResult.length);
				}
				reader.readAsText(csvFile);
			}
		});
	</script>
@endpush